
// let email = document.getElementById("email").value;
// let pno = document.getElementById("pno").value;
// let pwd = document.getElementById("pwd").value;
// let error = document.getElementById("error");
// let error1 = document.getElementById("error1");
// let error2 = document.getElementById("error2");
// let error3 = document.getElementById("error3");

//     var reg = /^([A-Za-z0-9\.-]+)@([A-Za-z0-9\-]+).([a-z]{2,3})(.[a-z]{2,3})?$/
//     var reg1 = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{8,15}$/
//     var reg2 = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/
    
// function validate()
// {
    
//     let email = document.getElementById("email").value;
//     let pno = document.getElementById("pno").value;
//     let pwd = document.getElementById("pwd").value;
//     let error = document.getElementById("error");
//     let error1 = document.getElementById("error1");
//     let error2 = document.getElementById("error2");
//     let error3 = document.getElementById("error3");
    
 
//     if(reg.test(email)&&reg1.test(pwd)&&reg2.test(pno)){
//         error.innerHTML = "Valid Email";
//         error1.innerHTML = "Valid password";
//         error3.innerHTML = "Valid phonenumber";
//         error.style.color = "blue";
//         error1.style.color = "blue";
//         error3.style.color = "blue";
      
//         return true;
//         ontype();       
                
//     }
        
//     else if(reg.test(email.value)) {
//         error.innerHTML = "Valid Email";
//         error.style.color = "blue";
//         return false;
        
//     }
//     else if(reg.test!=(email.value)){
//         error.innerHTML = "Invalid Email";
//         error.style.color = "red";
//         return false;
//     }
//     else if(reg2.test(pno.value)){
//         error3.innerHTML = "Valid Number";
//         error3.style.color = "blue";
//         return false;
//     }
//     else if(reg2.test!=(pno.value)){
//         error3.innerHTML = "Invalid Number";
//         error3.style.color = "red";
//         return false;
//     }

//     else {
//         error1.innerHTML = "Invalid pwd";
//         error.style.color = "red";
//     }
    
// }
// function ontype(){
//     if(pwd.value.length<8) {
//         error1.innerHTML = "Invalid Pwd";
//         error1.style.color = "red";
        
//     }
//     else if(pwd.value.length==8||pwd.value.length<=10){
//         error1.innerHTML = "poor";
//         error1.style.color="red";
//     }
//     else if(pwd.value.length==11||pwd.value.length<=13){
//         error1.innerHTML = "medium";
//         error1.style.color="skyblue";
//     }
//     else {
//         error1.innerHTML = "strong";
//         error1.style.color = "green";
//     }
    
// }
// function check(){
//     if(reg1.test!=(pwd.value)){
//        error2.innerHTML = "Password must contain an uppercase,a lowercase,a digit,special character!!.";
//        error2.style.color = "red";
//        return true;
//     }
    
// }

// function numbercheck(){
//     if(pno.value.length==10){
//         error3.innerHTML = "Valid Number";
//         error3.style.color = "blue";
//         return false;
//     }
//     else{
//         error3.innerHTML = "Invalid Number";
//         error3.style.color = "red";
//         return true;
//     }
// }

function registration()
	{

		var name= document.getElementById("t1").value;
		var email= document.getElementById("t2").value;
		var uname= document.getElementById("t3").value;
		var pwd= document.getElementById("t4").value;			
		var cpwd= document.getElementById("t5").value;
		
        //email id expression code
		var pwd_expression = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-])/;
		var letters = /^[A-Za-z]+$/;
		var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

		if(name=='')
		{
			alert('Please enter your name');
		}
		else if(!letters.test(name))
		{
			alert('Name field required only alphabet characters');
		}
		else if(email=='')
		{
			alert('Please enter your user email id');
		}
		else if (!filter.test(email))
		{
			alert('Invalid email');
		}
		else if(uname=='')
		{
			alert('Please enter the user name.');
		}
		else if(!letters.test(uname))
		{
			alert('User name field required only alphabet characters');
		}
		else if(pwd=='')
		{
			alert('Please enter Password');
		}
		else if(cpwd=='')
		{
			alert('Enter Confirm Password');
		}
		else if(!pwd_expression.test(pwd))
		{
			alert ('Upper case, Lower case, Special character and Numeric letter are required in Password filed');
		}
		else if(pwd != cpwd)
		{
			alert ('Password not Matched');
		}
		else if(document.getElementById("t5").value.length < 6)
		{
			alert ('Password minimum length is 6');
		}
		else if(document.getElementById("t5").value.length > 12)
		{
			alert ('Password max length is 12');
		}
		else
		{				                            
              
			   window.location = "../src/views/login.ejs"; 
		}
	}