const express = require(`express`);

const booksRouter = express.Router();
function router(nav) {
    var books = [
        {
            title:'Balyakalasakhi',
            author:'Vaikkom Muhammad Basheer',
            genre:'Novel',
            img:"balyakalasakhi.jpg"
        },
        {
            title:'The Power Of Your Subconscious Mind',
            author:'Dr Joseph Murphy',
            genre:'Self-help book',
            img:"images/power.jpg"
        },
        {
            title:'Five Point Someone',
            author:'Chetan Bhagat',
            genre:'Novel',
            img:"images/fivepoint.jpg"
        }
    ]
    booksRouter.get('/',function(req,res){
        res.render("books",
        {
          nav,
          title:'Books',
          books  
        });
    });
    booksRouter.get('/:i',function(req,res){
        const i = req.params.i
        res.render('book',{
            nav,
            title:'Book',
            book : books[i]
        });
    });

    return booksRouter;
    
}


module.exports = router;