const express = require('express');
const author = express.Router();
function router1(nav) {
    var authors = [
        {
            name:'Vaikkom Muhammad Basheer',
            books:'Paathummayude aadu, Premalekhanam, Mathilukal, Shabdhangal, Vishwavikhyathamaya Mooku, etc',
            img:"basheersir.jpg"
        },
        {
            name:'Dr Joseph Murphy',
            books:'The Miracles of Your Mind, Believe in yourself, Magic of Faith, Techniques in Prayer Therapy, etc',
            img:"josephmurphy.jpg"
        },
        {
            
            name:'Chetan Bhagat',
            books:'Five Point Someone,2 States,Half Girlfriend,Revolution Twenty20,One Indian Girl',
            img:"chetan.jpg"
        }
    ]
    author.get('/',function(req,res){
        res.render("authors",
        {
          nav,
          title:'Authors',
          authors  
        });
    });
    

    return author;
    
}


module.exports = router1;